import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class oneliner2 extends PApplet {



/*
moved[i][j]=0\u3000\u5857\u3063\u3066\u306a\u3044\u30de\u30b9
moved[i][j]=1  \u5857\u3063\u305f\u30de\u30b9
moved[i][j]=2  \u5857\u308c\u306a\u3044\u30de\u30b9
*/

Minim minims,minimp,minim;
AudioPlayer sound,pop;
//SoundFile sound, pop;
SoundButton mute;
Cyber cy,cy1;
Line li;
Make_stage ms=new Make_stage(2);
int n=2, frameX=50, frameY=150;
float leng=500.0f/n;
int moved[][]=new int[10][10];
int stage=0;
ArrayList<PVector> prev=new ArrayList<PVector>();
int prevx=0, prevy=-1;
boolean cleared=false,isdelay=false;
int delay_start=0;
ArrayList<PVector> obs=new ArrayList<PVector>();
PImage title_info,title;

public void setup() {
  
  resize_parameter();
  
  minim=new Minim(this);
  sound=minim.loadFile("voice1.wav");
  sound.loop();
  pop=minim.loadFile("pop.wav");
  pop.setLoopPoints(170,250);
  pop.loop();
  pop.mute();
  
  mute = new SoundButton(width-100,10,90,90,0xffEEEEEE);
  title_info=loadImage("info1.png");
  title=loadImage("title.png");
  cy=new Cyber(30,120,200);
  cy1=new Cyber(30,120,200);
  li=new Line();
  textSize(50);
  stroke(100);
  
  init();
}

public void draw() {
  background(100);
  textSize(30);
  fill(255);
  if(stage>0)text("push 'R' to generate new stage.",100,height-10);
  textSize(50);
  mute.move();
  fill(255);
  
  if(stage==0){
    li.move();
    image(title_info,width/2-150,10,300,300);
    image(title,185,575,240,120);
  }
  else {
    if(stage%5==0){
      pushMatrix();
      translate(width/2,height/2+50);
      cy.show();
      popMatrix();
    }
    text("stage"+stage,200,100);
  }
  for (int i=0; i<n; i++) {
    for (int j=0; j<n; j++) {
      if (moved[i][j]==0)fill(255);
      else if(moved[i][j]==1)fill(255,0,0,100);
      else if(moved[i][j]==2)fill(100);
      rect(frameX+i*leng, frameY+j*leng, leng, leng);
    }
  }
  
  
  clear_performance();
}

public void mouseDragged() {
  for (int i=0; i<n; i++) {
    for (int j=0; j<n; j++) {
      if(cleared)break;
      if (frameX+i*leng<=mouseX && mouseX<=frameX+(i+1)*leng &&  frameY+j*leng<=mouseY && mouseY<=frameY+(j+1)*leng) {
        if ((prevx!=i || prevy!=j)&&(abs(i-prevx)+abs(j-prevy)>1))continue;
        if ((prevx!=i || prevy!=j)&&abs(i-prevx)+abs(j-prevy)==1) {
          if (moved[i][j]==0) {
            prev.add(new PVector(i, j));
          } else if(moved[i][j]==1){
            while (true) {
              if (prev.size()==0)break;
              PVector now=prev.get(prev.size()-1);
              if (now.x==i && now.y==j)break;
              else {
                moved[(int)now.x][(int)now.y]=0;
                prev.remove(prev.size()-1);
              }
            }
          }
          if(moved[i][j]!=2){
            moved[i][j]=1;
            prevx=i;
            prevy=j;
          }
          if(isClear()){
            cleared=true;
            fill(255,0,0,100);
            rect(frameX+i*leng,frameY+j*leng,leng,leng);
            pop.unmute();
          }
        }
      }
    }
  }
}

/*
\u76e4\u9762\u304c\u30af\u30ea\u30a2\u6e08\u307f\u304b\u3069\u3046\u304b\u5224\u5b9a\u3059\u308b
*/
public boolean isClear() {
  for (int i=0; i<n; i++) {
    for (int j=0; j<n; j++) {
      if (moved[i][j]==0)return false;
    }
  }
  return true;
}

/*
\u30af\u30ea\u30a2\u3057\u305f\u6642\u306b\u547c\u3079\u3070\u3001\u30af\u30ea\u30a2\u6f14\u51fa\u304c\u3067\u304d\u308b
*/
public void clear_performance(){
  if(!cleared)return;
  if((frameCount%3==1 || frameCount%3==0))return;
  
  if(prev.size()==0){
   cleared=false;
   stage++;
   resize_parameter();
   init();
   pop.mute();
   return;
  }
  PVector now=prev.get(prev.size()-1);
  moved[(int)now.x][(int)now.y]=0;
  prev.remove(prev.size()-1);
  return;
}

/*
\u76e4\u9762\u60c5\u5831\u3092\u751f\u6210\u3059\u308b\u3002stage\u756a\u76ee\u306eArrayList\u306b\u683c\u7d0d\u3055\u308c\u3066\u3044\u308b\u969c\u5bb3\u30de\u30b9\u60c5\u5831\u3092\u8aad\u307f\u53d6\u308a\u3001\u53cd\u6620
*/
public void init() {
  for (int i=0; i<n; i++) {
    for (int j=0; j<n; j++) {
      moved[i][j]=0;
    }
  }
  if(stage==0){
    obs.add(new PVector(0,0));
  }
  for(int i=1;i<obs.size();i++){
    PVector p=obs.get(i);
    moved[(int)p.x][(int)p.y]=2;
  }
  PVector start=obs.get(0);
  moved[(int)start.x][(int)start.y]=1;
  prevx=(int)start.x;
  prevy=(int)start.y;
  //d();
  
  return;
}

/* debug\u51fa\u529b */
public void d(){
 for(int i=0;i<n;i++){
  for(int j=0;j<n;j++)print(moved[i][j]); 
  println();
 }
 println();
}

/*
\u30b9\u30c6\u30fc\u30b8\u306b\u3088\u308a\u30de\u30b9\u76ee\u306e\u6570\u304c\u5909\u308f\u308b\u306e\u3067\u3001\u305d\u3053\u306e\u51e6\u7406
*/
public void resize_parameter(){
   int num_obs=5;
   if(stage==0)n=2;
   else if(stage<6)n=5;
   else if(stage<13)n=6;
   else if(stage<19)n=7;
   else if(stage<21)n=8;
   else n=PApplet.parseInt(random(5,9));
   num_obs=5+3*(n-5);
   leng=500.0f/n;
   if(stage==0) {
     leng=100;
     frameX=200;
     frameY=350;
   }else {
     frameX=50;
     frameY=150;
   }
   ms.set_size(n);
   if(stage!=0){
     ms.set_obj(num_obs);
     obs=ms.get_obj();
   }
   ms.debug_print();
   ms.debug_print2();
}

/* 
n*n\u306e\u30b5\u30a4\u30ba\u306e\u76e4\u9762\u3092\u751f\u6210  
intput 1 : \u76e4\u9762\u30b5\u30a4\u30ba
*/
public int[][] generate_stage(int n){
   int v[][]=new int[n][n];
   for(int i=0;i<n;i++)for(int j=0;j<n;j++)v[i][j]=0;
   return v;
}

public void mousePressed(){
  if(mute.x<=mouseX && mouseX<=mute.w+mute.x && mute.y<=mouseY && mouseY<=mute.y+mute.h){
   if(!sound.isMuted())sound.mute();
   else {
     sound=minim.loadFile("voice1.wav");
     sound.loop();
   }
  }
}

public void mouseReleased() {
  if(cleared)return;
  init();
  prev.clear();
}

public void keyPressed(){
 if(key==ESC){
   minim.stop();
   exit();
 }
 if(key=='r'){
    println("pushed_ R");
    ms.set_obj(5);
    obs=ms.get_obj();
    init();
 }
}
class Cyber{
  int n;
  float size[]=new float[2];
  float deg[],add_deg[];
  PVector pos[];
  float noise_seed[];
  Cyber(int n, float size1, float size2){
    this.n=n;
    deg=new float[n];
    add_deg=new float[n];
    noise_seed=new float[n];
    pos=new PVector[n];
    for(int i=0;i<n;i++)pos[i]=new PVector(0,0);
    
    this.size[0]=size1;
    this.size[1]=size2;
    for(int i=0;i<n;i++){
      deg[i]=random(0,361);
      add_deg[i]=radians(random(0.1f,2.0f));
      noise_seed[i]=random(10000);
    }
  }
  
  public void show(){
    for(int i=0;i<n;i++){
     float noi=map(noise(noise_seed[i]),0,1,-20,20);
     pos[i].x=(size[i/(n/2)]+noi)*cos(deg[i]); 
     pos[i].y=(size[i/(n/2)]+noi)*sin(deg[i]);
     deg[i]+=add_deg[i];
     noise_seed[i]+=0.01f;
    }
    stroke(0xffFFFFFF);
    for(int i=0;i<n;i++){
      for(int j=i+1;j<n;j++){
        if(pos[i].dist(pos[j])<80){
          strokeWeight(map(pos[i].dist(pos[j]),0,80,0,3));
          line(pos[i].x,pos[i].y,pos[j].x,pos[j].y); 
        }
      }
    }
    strokeWeight(1);
    stroke(100);
  }
}
class SoundButton{
  int x,y,w,h;
  int c;
  PImage mute,play;
 SoundButton(int x, int y, int w, int h, int c) {
   this.x=x; this.y=y; this.w=w; this.h=h; this.c=c;
   mute=loadImage("mute1.png");
   play=loadImage("play1.png");
 }
 
 public void move(){
   fill(c);
   rect(x,y,w,h);
   if(!sound.isMuted())image(mute,x,y,w,h);
   else image(play,x,y,w,h);
 }
}
class Make_stage{
  int n;
  int stage[][]=new int[10][10];
  int degree[][]=new int[10][10];
  Make_stage(int _n){
    n=_n; 
    for(int i=0;i<n;i++)
      for(int j=0;j<n;j++)
        stage[i][j]=0;
  }
  
  //\u969c\u5bb3\u7269\u3092\u8a2d\u7f6e\u3059\u308b
  //input1 \u8a2d\u7f6e\u3057\u305f\u3044\u969c\u5bb3\u7269\u306e\u500b\u6570
  public void set_obj(int num){
   for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
       stage[i][j]=0;
   for(int i=0;i<num;i++){
    boolean ok=put_obj();
    if(!ok)return;
   }
   return;
  }
  
  
  //\u4eca\u306e\u72b6\u614b\u304b\u3089\u3001\u30e9\u30f3\u30c0\u30e0\u306b\u969c\u5bb3\u7269\u3092\u8a2d\u7f6e\u3059\u308b
  public boolean put_obj(){
    int sy=PApplet.parseInt(random(n));
    int sx=PApplet.parseInt(random(n));
    int dx[]={0,1,0,-1};
    int dy[]={1,0,-1,0};
    for(int i=sy;i<sy+n;i++){ //\u3069\u3053\u306b\uff12\u3092\u7f6e\u304f\u304b\u5168\u63a2\u7d22
     for(int j=sx;j<sx+n;j++){
       if(stage[i%n][j%n]==2)continue;
       stage[i%n][j%n]=2;
       
       for(int p=0;p<n;p++){ //\u6b21\u6570\u30c6\u30fc\u30d6\u30eb\u306e\u69cb\u7bc9
        for(int q=0;q<n;q++){
          if(stage[p][q]==2){
            degree[p][q]=-1;
            continue;
          }
          int ct=0;
          for(int idx=0;idx<4;idx++){
            int nx=q+dy[idx];
            int ny=p+dx[idx];
            ct+=grid_score(nx,ny);
          }
          degree[p][q]=ct;
        }
       }
       
       if(f())return true;
       println("failed to find path");
       stage[i%n][j%n]=0;
      
     }
    }
    return false;
  }
  //\u6b21\u6570\u30c6\u30fc\u30d6\u30eb\u3092\u5143\u306b\u3001\u305d\u308c\u304c\u4e00\u7b46\u66f8\u304d\u3067\u304d\u308b\u3082\u306e\u304b\u5224\u5b9a
  public boolean f(){
    int dx[]={1,0,-1,0};
    int dy[]={0,1,0,-1};
    //int dx[]={0,1,0,-1};
    //int dy[]={-1,0,1,0};
   while(true){
     boolean finish=true;
     for(int i=0;i<n;i++){
      for(int j=0;j<n;j++){
         if(degree[i][j]>=3){
           for(int k=0;k<4;k++){
             int nx=j+dx[k];
             int ny=i+dy[k];
             if(!in(nx,ny))continue;
             if(degree[ny][nx]>=2){
               degree[i][j]--;
               degree[ny][nx]--;
               finish=false;
               break;
             }
           }
         }
        }
      }
      //debug_print2();
      //println();
      if(finish)break;
   }
      
      int odd=0;
      for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
           if(degree[i][j]%2==1)odd++;
        }
      }
      if(odd!=0 && odd!=2)return false;
      if(bfs())return true;
      else return false;
   }
  
  //\u3000\u5ea7\u6a19\u304c\u76e4\u9762\u5185\u3067\u3001\u304b\u3064\u969c\u5bb3\u30de\u30b9\u3067\u306a\u3044
  public int grid_score(int x,int y){
    int ret=0;
    if(0<=x&&0<=y&&x<n&&y<n){
      //ret++;
      if(stage[y][x]==0)ret++;
    }
    return ret;
  }
  
  
  //\u969c\u5bb3\u7269\u306e\u4f4d\u7f6e\u3092\u683c\u7d0d\u3057\u305fArrayList\u3092\u53d6\u5f97
  public ArrayList<PVector> get_obj(){
  ArrayList<PVector> ret=new ArrayList<PVector>();
  ArrayList<PVector> ones=new ArrayList<PVector>();
  ArrayList<PVector> twos=new ArrayList<PVector>();
  debug_print2();
   for(int i=n-1;i>=0;i--)
     for(int j=n-1;j>=0;j--)
       if(degree[i][j]==1){
         ones.add(new PVector(j,i));
       }else if(degree[i][j]==2){
         twos.add(new PVector(i,j));
       }
   if(ones.size()>0){
     stage[PApplet.parseInt(ones.get(0).y)][PApplet.parseInt(ones.get(0).x)]=2;
     if(!bfs()){
       stage[PApplet.parseInt(ones.get(0).y)][PApplet.parseInt(ones.get(0).x)]=0;
       ret.add(new PVector(PApplet.parseInt(ones.get(1).x),PApplet.parseInt(ones.get(1).y)));
     }else {
       stage[PApplet.parseInt(ones.get(0).y)][PApplet.parseInt(ones.get(0).x)]=0;
       ret.add(new PVector(PApplet.parseInt(ones.get(0).x),PApplet.parseInt(ones.get(0).y)));
     }
   }else {
     int idx=PApplet.parseInt(random(0,twos.size()));
     ret.add(new PVector(PApplet.parseInt(twos.get(idx).x), PApplet.parseInt(twos.get(idx).y)));
   }
   
   for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
      if(stage[i][j]==2)ret.add(new PVector(j,i));
    }
   }
   //\u5168\u3066\u306e\u9802\u70b9\u304c\u5076\u70b9\u3067\u3042\u308b\u3068\u304d\u3001\u5de6\u4e0a\u3092\u59cb\u70b9\u3068\u3059\u308b
   if(ret.size()==0)ret.add(new PVector(0,0));
   return ret;
  }
  
  public boolean in(int x,int y){
   return (0<=x&&0<=y&&x<n&&y<n); 
  }
  
  public boolean bfs(){
    int dx[]={1,0,-1,0};
    int dy[]={0,1,0,-1};
     boolean visited[][]=new boolean[10][10];
      for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
          visited[i][j]=false;
      for(int i=0;i<n;i++){
       for(int j=0;j<n;j++){
         if(stage[i][j]==0){
           ArrayList<PVector> queue=new ArrayList<PVector>();
           queue.add(new PVector(j,i));
           visited[i][j]=true;
           while(queue.size()>0){
             PVector now=queue.get(0);
             queue.remove(0);
             for(int k=0;k<4;k++){
              int nx=PApplet.parseInt(now.x)+dx[k];
              int ny=PApplet.parseInt(now.y)+dy[k];
              if(in(nx,ny) && stage[ny][nx]==0 && !visited[ny][nx]){
                 queue.add(new PVector(nx,ny));
                 visited[ny][nx]=true;
              }
             }
           }
           
           for(int p=0;p<n;p++){
            for(int q=0;q<n;q++){
              if(stage[p][q]==0 && !visited[p][q]){
                return false;
              }
            }
           }
           return true;
         }
       }
      }
      return false;
  }
  
  public void debug_print(){
   for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
     if(j>0)print(" ");
     print(stage[i][j]);
    }
    println();
   }
   println();
  }
  
  public void debug_print2(){
    for(int i=0;i<n;i++){
     for(int j=0;j<n;j++){
      if(j>0)print(" ");
      print(degree[i][j]);
     }
     println();
    }
    println();
  }
  
  public void set_size(int _n){
    this.n=_n;
  }
}

// <---------------------------------------------------------->
/*
class Make_stage{
  int n;
  int stage[][]=new int[10][10];
  int degree[][]=new int[10][10];
  Make_stage(int _n){
    n=_n; 
    for(int i=0;i<n;i++)
      for(int j=0;j<n;j++)
        stage[i][j]=0;
  }
  
  //\u969c\u5bb3\u7269\u3092\u8a2d\u7f6e\u3059\u308b
  //input1 \u8a2d\u7f6e\u3057\u305f\u3044\u969c\u5bb3\u7269\u306e\u500b\u6570
  void set_obj(int num){
   for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
       stage[i][j]=0;
   for(int i=0;i<num;i++){
    boolean ok=put_obj();
    if(!ok)return;
   }
   return;
  }
  
  
  //\u4eca\u306e\u72b6\u614b\u304b\u3089\u3001\u30e9\u30f3\u30c0\u30e0\u306b\u969c\u5bb3\u7269\u3092\u8a2d\u7f6e\u3059\u308b
  boolean put_obj(){
    int sy=int(random(n));
    int sx=int(random(n));
    int dx[]={0,1,0,-1};
    int dy[]={1,0,-1,0};
    for(int i=sy;i<sy+n;i++){ //\u3069\u3053\u306b\uff12\u3092\u7f6e\u304f\u304b\u5168\u63a2\u7d22
     for(int j=sx;j<sx+n;j++){
       if(stage[i%n][j%n]==2)continue;
       stage[i%n][j%n]=2;
       
       for(int p=0;p<n;p++){ //\u6b21\u6570\u30c6\u30fc\u30d6\u30eb\u306e\u69cb\u7bc9
        for(int q=0;q<n;q++){
          if(stage[p][q]==2){
            degree[p][q]=-1;
            continue;
          }
          int ct=0;
          for(int idx=0;idx<4;idx++){
            int nx=q+dy[idx];
            int ny=p+dx[idx];
            ct+=grid_score(nx,ny);
          }
          degree[p][q]=ct;
        }
       }
       
       if(f())return true;
       println("failed to find path");
       stage[i%n][j%n]=0;
      
     }
    }
    return false;
  }
  //\u6b21\u6570\u30c6\u30fc\u30d6\u30eb\u3092\u5143\u306b\u3001\u305d\u308c\u304c\u4e00\u7b46\u66f8\u304d\u3067\u304d\u308b\u3082\u306e\u304b\u5224\u5b9a
  boolean f(){
    int dx[]={1,0,-1,0};
    int dy[]={0,1,0,-1};
   while(true){
     boolean finish=true;
     for(int i=0;i<n;i++){
      for(int j=0;j<n;j++){
         if(degree[i][j]>=3){
           for(int k=0;k<4;k++){
             int nx=j+dx[k];
             int ny=i+dy[k];
             if(!in(nx,ny))continue;
             if(degree[ny][nx]>=2){
               degree[i][j]--;
               degree[ny][nx]--;
               finish=false;
               break;
             }
           }
         }
        }
      }
      //debug_print2();
      //println();
      if(finish)break;
   }
      
      int odd=0;
      for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
           if(degree[i][j]%2==1)odd++;
        }
      }
      if(odd!=0 && odd!=2)return false;
      
      boolean visited[][]=new boolean[10][10];
      for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
          visited[i][j]=false;
      for(int i=0;i<n;i++){
       for(int j=0;j<n;j++){
         if(stage[i][j]==0){
           ArrayList<PVector> queue=new ArrayList<PVector>();
           queue.add(new PVector(j,i));
           visited[i][j]=true;
           while(queue.size()>0){
             PVector now=queue.get(0);
             queue.remove(0);
             for(int k=0;k<4;k++){
              int nx=int(now.x)+dx[k];
              int ny=int(now.y)+dy[k];
              if(in(nx,ny) && stage[ny][nx]==0 && !visited[ny][nx]){
                 queue.add(new PVector(nx,ny));
                 visited[ny][nx]=true;
              }
             }
           }
           
           for(int p=0;p<n;p++){
            for(int q=0;q<n;q++){
              if(stage[p][q]==0 && !visited[p][q]){
                return false;
              }
            }
           }
           return true;
         }
       }
      }
      return false;
      
   }
  
  //\u3000\u5ea7\u6a19\u304c\u76e4\u9762\u5185\u3067\u3001\u304b\u3064\u969c\u5bb3\u30de\u30b9\u3067\u306a\u3044
  int grid_score(int x,int y){
    int ret=0;
    if(0<=x&&0<=y&&x<n&&y<n){
      //ret++;
      if(stage[y][x]==0)ret++;
    }
    return ret;
  }
  
  
  //\u969c\u5bb3\u7269\u306e\u4f4d\u7f6e\u3092\u683c\u7d0d\u3057\u305fArrayList\u3092\u53d6\u5f97
  ArrayList<PVector> get_obj(){
    ArrayList<PVector> ret=new ArrayList<PVector>();
   for(int i=n-1;i>=0;i--)
     for(int j=n-1;j>=0;j--)
       if(degree[i][j]%2==1 && ret.size()==0){
         ret.add(new PVector(j,i));
         break;
       }
   for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
      if(stage[i][j]==2)ret.add(new PVector(j,i));
    }
   }
   //\u5168\u3066\u306e\u9802\u70b9\u304c\u5076\u70b9\u3067\u3042\u308b\u3068\u304d\u3001\u5de6\u4e0a\u3092\u59cb\u70b9\u3068\u3059\u308b
   if(ret.size()==0)ret.add(new PVector(0,0));
   return ret;
  }
  
  boolean in(int x,int y){
   return (0<=x&&0<=y&&x<n&&y<n); 
  }
  
  void debug_print(){
   for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
     if(j>0)print(" ");
     print(stage[i][j]);
    }
    println();
   }
   println();
  }
  
  void debug_print2(){
    for(int i=0;i<n;i++){
     for(int j=0;j<n;j++){
      if(j>0)print(" ");
      print(degree[i][j]);
     }
     println();
    }
    println();
  }
  
  void set_size(int _n){
    this.n=_n;
  }
}
*/
class Line {
  float noise_seed[]=new float[2];
  float w=50;
  Line(){
    for(int i=0;i<2;i++)noise_seed[i]=random(10000);
  }
  public void move(){
    fill(0xffFFFFFF, 100);
    float line1_x=(width-w)*noise(noise_seed[0]);
    float line2_y=(height-w)*noise(noise_seed[1]);
    rect(line1_x, 0, w,height);
    rect(0,line2_y, width, w);
    for(int i=0;i<2;i++)noise_seed[i]+=0.005f;
  }
}
  public void settings() {  size(600, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "oneliner2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
